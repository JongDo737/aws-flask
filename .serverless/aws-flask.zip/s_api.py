import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='jongdo737',
    application_name='aws-flask',
    app_uid='m3mjwlJ4QN02Mt2K5J',
    org_uid='f12a6e38-267b-44f9-9035-11588a2c3633',
    deployment_uid='fd154fdb-c313-45f6-ab5e-097989adb6e1',
    service_name='aws-flask',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-flask-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
